// VideoFSA.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

#define HORIZONTALTOTAL     57
#define HORIZONTALACTIVE    32
#define HSYNCSTART          41         
#define HSYNCWIDTH          7

#define VERTICALTOTAL       525
#define VERTICALACTIVE      384
#define VSYNCSTART          454
#define VSYNCWIDTH          2

#define EVENADDRESS         0x0000
#define ODDADDRESS          0x2000
#define HORIZONTALBORDER    0x4000
#define VERTICALBORDER      0x8000
#define SYNCADDRESS         0xC000
#define INTERRUPTWIDTH      15

#define HSYNC               0x1000
#define VSYNC               0x2000
#define EPROMSIZE           0x10000

unsigned int EPROM[EPROMSIZE];


//	Data comes int assuming data signals are contiguous on the 27c322 ROM
//	Data goes out in the correct position on the chip
unsigned int SwizzleData(unsigned int val)
{
    unsigned int ret;

    ret = 0;
    for (int i = 0; i < 16; i++) {
        if (val & (1 << i)) ret |= ((i & 1) ? (1 << ((i & 14) >> 1) + 8) : (1 << ((i >> 1))));
    }
    for (int i = 16; i < 32; i++) {
        if (val & (1 << i)) ret |= ((i & 1) ? (1 << ((i & 14) >> 1) + 24) : (1 << (((i & 14) >> 1)) + 16));
    }
    return ret;
}

//	Data in the correct position on the chip
//	Data goes out assuming data signals are contiguous on the 27c322 ROM
//  The native pinout of the chip effectively performs the Deswizzle from pinout to circuit
unsigned int DeSwizzleData(unsigned int val)
{
    unsigned int ret;

    ret = 0;
    for (int i = 0; i < 16; i++) {
        if (val & (1 << i)) ret |= ((i & 8) ? (1 << (((i & 7) * 2) + 1)) : (1 << (i * 2)));
    }
    for (int i = 16; i < 32; i++) {
        if (val & (1 << i)) ret |= ((i & 8) ? (1 << (((i & 7) * 2) + 17)) : (1 << (((i & 7) * 2) + 16)));
    }
    return ret;
}


void    SwapSpectrumBits(unsigned int* address)
{
    //   return;
    unsigned int value = *address;
    *address = (value & 0xf81f) | ((value >> 3) & 0x00e0) | ((value << 3) & 0x0700);
}

//  Complex mapping for raster generator.
unsigned int    ComputeAddress(int baserow, int basecolumn)
{
    int row = baserow;
    int column = basecolumn;
    unsigned int address = 0x0000;
    if (column >= HORIZONTALTOTAL) {
        column = 0;
        row++;
        if (row >= VERTICALTOTAL) row = 0;
    }
    if ((row < VERTICALACTIVE) && (column < HORIZONTALACTIVE)) {
        address = ((row / 2) * HORIZONTALACTIVE + column) + ((row & 0x01) ? ODDADDRESS : EVENADDRESS);
        SwapSpectrumBits(&address);
        return address;
    }

    if ((row == VSYNCSTART - 1) && (column < INTERRUPTWIDTH)) {
        address = 0xc800 + column;
        SwapSpectrumBits(&address);
        return address;
    }
    if (((column >= HSYNCSTART) && (column < (HSYNCSTART + HSYNCWIDTH))) ||
        ((row >= VSYNCSTART) && (row < (VSYNCSTART + VSYNCWIDTH)))) {           //  We are in sync
        address = SYNCADDRESS;
        if ((column >= HSYNCSTART) && (column < (HSYNCSTART + HSYNCWIDTH))) {   //  HSYNC is active
            if ((row >= VSYNCSTART) && (row < (VSYNCSTART + VSYNCWIDTH))) address |= VSYNC;
            address |= (HSYNC + (row * HSYNCWIDTH) + (column - HSYNCSTART));
            SwapSpectrumBits(&address);
            return address;
        }
        else {
            address |= (VSYNC + (row - VSYNCSTART) * HORIZONTALTOTAL + (column));
            SwapSpectrumBits(&address);
            return address;
        }
    }

    if (column == (HSYNCSTART - 1)) {
        address = SYNCADDRESS + row;
        SwapSpectrumBits(&address);
        return address;
    }
    if (column == (HSYNCSTART + HSYNCWIDTH)) {
        address = SYNCADDRESS + row + 0x400;
        SwapSpectrumBits(&address);
        return address;
    }

    if (row < VERTICALACTIVE) {
        //  Compute horizontal border
        address = HORIZONTALBORDER + (row * (HORIZONTALTOTAL - HORIZONTALACTIVE)) + (column - HORIZONTALACTIVE);
    }
    else {
        //  Compute vertical border
        address = VERTICALBORDER;
        address += ((row - VERTICALACTIVE) * HORIZONTALTOTAL) + column;
    }
    SwapSpectrumBits(&address);
    return address;
}

int main()
{
    char fname[64] = "VideoFSA.bin";
    std::cout << "Generating ZX Spectrum VGA EPROM!" << '\n';
    for (int i = 0; i < EPROMSIZE; i++) {
        EPROM[i] = 0;
    }

    for (int row = 0; row < VERTICALTOTAL; row++) {
        for (int column = 0; column < HORIZONTALTOTAL; column++) {
            unsigned int address = ComputeAddress(row, column);
            unsigned int nextAddress = ComputeAddress(row, column + 1);

            EPROM[address] = SwizzleData(nextAddress);
        }
    }

    std::cout << "Writing EPROM " << fname;
    FILE* fp;
    fopen_s(&fp, fname, "w+b");
    for (int i = 0; i < EPROMSIZE; i++) {
        fputc(EPROM[i] & 0xff, fp);
        fputc((EPROM[i] >> 8) & 0xff, fp);
    }
    fclose(fp);
 }

